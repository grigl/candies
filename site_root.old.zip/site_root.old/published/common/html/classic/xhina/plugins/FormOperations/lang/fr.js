// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Insert a Form.": "Insérer un formulaire",
  "Insert a text, password or hidden field.": "Insérer un texte, un mot de passe ou un champ invisible",
  "Insert a multi-line text field.": "Insérer un champ texte à lignes multiples",
  "Insert a select field.": "Insérer une boite de sélection",
  "Insert a check box.": "Insérer une case à cocher",
  "Insert a radio button.": "Insérer un bouton radio",
  "Insert a submit/reset button.": "Insérer un bouton de soumission/annulation"
};