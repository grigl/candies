// I18N constants
// LANG: "pl", ENCODING: UTF-8
// translated: Krzysztof Kotowicz, http://www.eskot.krakow.pl/portfolio/, koto@webworkers.pl
{
  "Paste as Plain Text": "Wklej jako czysty tekst"
};
