// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Decimal numbers": "Nombres décimaux",
  "Lower roman numbers": "Nombres romains minuscule",
  "Upper roman numbers": "Nombres romains majuscule",
  "Lower latin letters": "Lettres latines minuscule",
  "Upper latin letters": "Lettres latines majuscule",
  "Lower greek letters": "Lettres grecques minuscule",
  "Choose list style type (for ordered lists)": "Choisissez le style de liste (pour les listes ordonnées)"
};