// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Paste as Plain Text": "Copier comme texte pur"
};