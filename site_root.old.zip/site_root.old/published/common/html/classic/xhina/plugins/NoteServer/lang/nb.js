// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Insert GUIDO Music Notation": "Sett inn GUIDO-noter",
  "Guido code": "GUIDO-kode",
  "Options": "Muligheter",
  "Format": "Format",
  "Image in applet": "Bilde i applet",
  "Zoom": "Forstørr",
  "MIDI File": "MIDIfil",
  "Image Preview": "Bilde forhåndsvisning",
  "Source Code": "Kildekode",
  "Preview": "Preview",
  "Add MIDI link to allow students to hear the music": "Legg til MIDI-link for at studenter kan høre musikken",
  "Add GUIDO Code in a textbox on the page": "Sett inn GUIDO-kode i et tekstfelt på siden"
};