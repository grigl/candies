// I18N for the Equation plugin
// LANG: "de", ENCODING: UTF-8
// Author: Joe Hobson, jhobson@bcoe.org
{
  "Equation Editor": "Gleichungs-Editor",
  "Select operation": "Auswahl",
  "Insert": "Einfügen",
  "Cancel": "Abbrechen"
};
