// I18N constants
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "You must select some text before making a new link.": "Du må markere tekst eller et bilde før du kan lage en lenke.",
  "Are you sure you wish to remove this link?": "Er du sikker på at du vil fjerne lenken?"
};