// LANG: "nb", ENCODING: UTF-8 | ISO-8859-1
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Insert Image": "Sett inn bilde",
  "Image Preview:": "Forhåndsvisning:",
  "Image URL:": "Bildets URL:",
  "Preview": "Forhåndsvisning",
  "Alternate text:": "Alternativ tekst",  
  "Layout": "Oppsett",
  "Alignment:": "Plassering",
  "Border thickness:": "Rammetykkelse:",
  "Spacing": "Luft rundt bildet",
  "Horizontal:": "Horisontal:",
  "Vertical:": "Vertikal:",
  "The file you are uploading doesn't have the correct extension.": "Bildet du laster opp har et ugyldig format, opplastning avbrutt",
  "The file you are uploading already exists.": "Bildet du prøver å laste opp eksisterer allerede på serveren",
  "The file you are uploading is to big. The max Filesize is": "Bildet du laster opp er for stort, maks tillatt størrelse er",
  "Images on the Server:": "Bilder på serveren:",
  "Please select a file to upload.": "Velg bilde du skal laste opp",
  "Upload file": "Last opp bilde",
  "Open file in new window": "Åpne bilde i nytt vindu"
};