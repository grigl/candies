// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Set page background image": "Définir l'image de fond",
  "Set Page Background Image": "Définir l'Image de Fond",
  "Remove Current Background": "Supprimer le fond actuel",
  "Cancel": "Annuler"
};