tinyMCE.addI18n('ru.toolbartoggle',{
	desc : 'Скрыть/показать дополнительные панели'
});