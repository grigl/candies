tinyMCE.addI18n('ru.paste',{
paste_text_title : 'Вставить как простой текст',
paste_text_desc : 'Используйте сочетание клавиш CTRL+V чтобы вставить текст в окно.',
paste_text_linebreaks : 'Сохранять разрывы строк',
paste_word_desc : 'Вставить из Word',
paste_word_title : 'Используйте сочетание клавиш CTRL+V чтобы вставить текст в окно.',
selectall_desc : 'Выделить всё'
});