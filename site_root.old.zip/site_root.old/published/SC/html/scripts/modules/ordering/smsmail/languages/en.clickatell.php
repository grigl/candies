<?php
define('SMSMAIL_MODULE_CLICKATELL_API_ID_TTL','API_ID');
define('SMSMAIL_MODULE_CLICKATELL_API_ID_DSCR','API_ID can be obtained in your Clickatell account');
define('SMSMAIL_MODULE_CLICKATELL_USER_TTL','Clickatell login');
define('SMSMAIL_MODULE_CLICKATELL_USER_DSCR','Please input your Clickatell account login');
define('SMSMAIL_MODULE_CLICKATELL_PASSWORD_TTL','Clickatell password');
define('SMSMAIL_MODULE_CLICKATELL_PASSWORD_DSCR','Please input your Clickatell account password');
define('SMSMAIL_MODULE_CLICKATELL_ORIGINATOR_TTL','Originator');
define('SMSMAIL_MODULE_CLICKATELL_ORIGINATOR_DSCR','The name of the sender of SMS messages. Max 16 chars for the number of the sender in international format, or max 11 char for a text string (use English letters only)');
?>