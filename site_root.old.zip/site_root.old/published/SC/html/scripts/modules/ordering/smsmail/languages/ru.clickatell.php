<?php
define('SMSMAIL_MODULE_CLICKATELL_API_ID_TTL','API_ID');
define('SMSMAIL_MODULE_CLICKATELL_API_ID_DSCR','API_ID Вы можете узнать в Вашей учетной записи на Clickatell');
define('SMSMAIL_MODULE_CLICKATELL_USER_TTL','Clickatell логин');
define('SMSMAIL_MODULE_CLICKATELL_USER_DSCR','Логин от Вашей учетной записи Clickatell');
define('SMSMAIL_MODULE_CLICKATELL_PASSWORD_TTL','Clickatell пароль');
define('SMSMAIL_MODULE_CLICKATELL_PASSWORD_DSCR','Пароль к Вашей учетной записи Clickatell');
define('SMSMAIL_MODULE_CLICKATELL_ORIGINATOR_TTL','Отправитель сообщения, как он будет выглядеть на телефоне получателя');
define('SMSMAIL_MODULE_CLICKATELL_ORIGINATOR_DSCR','Отправитель может состоять из цифр - в этом случае его длина ограничена 15-ю символами, или буквенно-цифровым (например, название вашей компании) - в этом случае длина ограничена 11-ю символами. Русские буквы в имени отправителя не разрешены.');
?>