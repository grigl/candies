<?php
$modes['Books, Top Selling']=1000;
$modes['Books, Bargain']=45;

$modes['Books, Audiocassettes']=44;
$modes['Books, Audio CDs']=69724;
$modes['Books, Business']=3;
$modes['Books, Cooking']=6;
$modes['Books, Home/Garden']=48;
$modes['Books, Literature/Fiction']=17;
$modes['Books, Nonfiction']=53;
$modes['Books, Technical']=173507;
$modes['Books, Romance']=23;

$modes['Books, Sports']=26;
$modes['Books, Childrens']=4;
$modes['Books, Engineering']=13643;
$modes['Books, Health']=10;
$modes['Books, Reference']=21;
$modes['Books, Science']=75;
$modes['Books, Biographies']=2;
$modes['Books, Computers/Internet']=5;
$modes['Books, Entertainment']=86;

$modes['Books, History']=9;
$modes['Books, Law']=10777;
$modes['Books, Mystery']=18;
$modes['Books, Religion']=22;
$modes['Books, SciFi/Fantasy']=25;
$modes['Books, Travel']=27;
$modes['Books, Arts & Photography']=1;
$modes['Books, e-books']=551440;

$modes['Books, Women\'s Fiction']=542654;

$modes['Magazines, Top Selling']=599872;
$modes['Magazines, Computer/Internet']=602324;
$modes['Magazines, Family']=602330;
$modes['Magazines, Games']=602336;
$modes['Magazines, History']=602342;
$modes['Magazines, Lifestyle']=602348;
$modes['Magazines, Music']=602354;

$modes['Magazines, Pets']=602360;
$modes['Magazines, Espanol']=1040158;
$modes['Magazines, Travel']=602370;
$modes['Magazines, Arts']=602314;
$modes['Magazines, Business']=602320;
$modes['Magazines, Electronics']=602326;
$modes['Magazines, Fashion']=602332;
$modes['Magazines, Home/Garden']=602344;
$modes['Magazines, Literary']=602350;

$modes['Magazines, Newspapers']=1040160;
$modes['Magazines, Religion']=602362;
$modes['Magazines, Sport']=602366;
$modes['Magazines, Womens']=602372;
$modes['Magazines, Automotive']=602316;
$modes['Magazines, Childrens']=602322;
$modes['Magazines, Entertainment']=602328;
$modes['Magazines, Food']= 602334;
$modes['Magazines, Health']=602340;

$modes['Magazines, International']=602346;
$modes['Magazines, Mens']=602352;
$modes['Magazines, News/Politics']=602358;
$modes['Magazines, Science/Nature']=602364;
$modes['Magazines, Teen']=602368; 	

$modes['DVDs, Top Selling']=286723;
$modes['DVDs, New & Future Releases']=404332;
$modes['DVDs, Animation']=712256;

$modes['DVDs, Classic']=163345;
$modes['DVDs, Documentary']=508532;
$modes['DVDs, Horror']=163396;
$modes['DVDs, SciFi/Fantasy']=163431;
$modes['DVDs, Television']=163450;
$modes['DVDs, Action/Adventure']=163296;
$modes['DVDs, Anime/Manga']=517956;
$modes['DVDs, Comedy']=163357;
$modes['DVDs, Drama']=163379;

$modes['DVDs, Kids/Family']=163414;
$modes['DVDs, Music Video']=163420;
$modes['DVDs, Special Interest']=163448;
$modes['DVDs, Military/War']=586156;
$modes['DVDs, Mystery/Suspense']=512030;
$modes['DVDs, Sports']=467970;
$modes['DVDs, African-American Cinema']=538708;
$modes['DVDs, International']=163313;
$modes['DVDs, Boxed Sets']=501230;

$modes['DVDs, Cult']=466674;
$modes['DVDs, Gay & Lesbian']=301667;
$modes['DVDs, Hong Kong Action']=464426;
$modes['DVDs, Independents']=901596;
$modes['DVDs, Musicals']=508528;
$modes['DVDs, Westerns']=163312 ;
$modes['Music, Top Selling']=301668;
$modes['Music, New & Future Releases']=465672;
$modes['Music, Classical']=85;
$modes['Music, Dance/DJ']=7;
$modes['Music, Pop']=37;
$modes['Music, Rock']=40;
$modes['Music, Alternative']=30;
$modes['Music, Classic Rock']=67204;
$modes['Music, Jazz']=34;

$modes['Music, Rap']=38;
$modes['Music, Soundtracks']=42;
$modes['Music, Blues']=31;
$modes['Music, Christian']=173429;
$modes['Music, Country']=16;
$modes['Music, Latin']=289122;
$modes['Music, R/B']=39 	;
$modes['Software, Top Selling']=491286;

$modes['Software, Communication']=229636;
$modes['Software, Graphics']=229614;
$modes['Software, Linux']=290562;
$modes['Software, Operating Sys']=229653;
$modes['Software, Downloadable']=531448;
$modes['Software, Utilities']=229672;
$modes['Software, Business']=229535;
$modes['Software, Education']=229563;
$modes['Software, Home/Hobby']=229624;

$modes['Software, Mac']=229643;
$modes['Software, Finance']=229540;
$modes['Software, Handhelds']=229663;
$modes['Software, Video']=497022;
$modes['Software, Childrens']=229548;
$modes['Software, Games']=229575;
$modes['Software, Language/Travel']=497026;
$modes['Software, Networking']=229637;
$modes['Software, Programming']=229667;

$modes['Software, Web Dev']=497024 ;	
$modes['VHS, Top Selling']=286721;
$modes['VHS, New & Future Releases']=286747;
$modes['VHS, Animation']=712260;
$modes['VHS, Classic']=127;
$modes['VHS, Documentary']=508530;
$modes['VHS, Horror']=131;
$modes['VHS, SciFi/Fantasy']=144;

$modes['VHS, Television']=136;
$modes['VHS, Action/Adventure']=141;
$modes['VHS, Anime/Manga']=281300;
$modes['VHS, Comedy']=128;
$modes['VHS, Drama']=129;
$modes['VHS, Kids/Family']=132;
$modes['VHS, Music Video']=133;
$modes['VHS, Special Interest']=135;
$modes['VHS, Military/War']=586154;

$modes['VHS, Mystery/Suspense']=512026;
$modes['VHS, Sports']=169798;
$modes['Video Games, Top Selling']=471280;
$modes['Video Games, Game Cube']=541022;
$modes['Video Games, Play Station 2']=301712;
$modes['Video games, Game Boy']=229783;
$modes['Video Games, Mac']=229647;
$modes['Video Games, PC']=229575;

$modes['Video Games, Game Boy Advance']=541020;
$modes['Video Games, Xbox']=537504; 	
$modes['Kitchen, Top Selling']=491864;
$modes['Kitchen, Outlet']=526844;
$modes['Kitchen, Coffee/Tea']=289742;
$modes['Kitchen, Cookware']=289814;
$modes['Kitchen, Appliances']=289913;
$modes['Kitchen, Baking']=289668;

$modes['Kitchen, Housewares']=510080;
$modes['Kitchen, Tableware']=289891;
$modes['Kitchen, Bar Tools']=289728;
$modes['Kitchen, Gadgets']=289754;
$modes['Kitchen, Knives']=289851; 	
$modes['Toys, Top Selling']=491290;
$modes['Toys, Crafts']=171859;
$modes['Toys, Dolls']=171569;

$modes['Toys, Games']=171689;
$modes['Toys, Outdoor']=171960;
$modes['Toys, Action Figures']=171662;
$modes['Toys, Bikes']=569472;
$modes['Toys, Electronics']=720366;
$modes['Toys, Stuffed Animals']=171992;
$modes['Toys, Learning']=171911;
$modes['Toys, Building']=171814;
$modes['Toys, Furniture']=172790;

$modes['Toys, Puzzles']=171744;
$modes['Toys, Vehicles']=171600; 
$modes['Outdoor, Top Selling']=468250;
$modes['Outdoor, Outlet']=526814 ;
$modes['Outdoor, Gifts']=553648;
$modes['Outdoor, Lawn/Garden Tools']=915484;
$modes['Outdoor, Pest Control']=553844;
$modes['Outdoor, Birding']=553632;

$modes['Outdoor, Grills']=553760;
$modes['Outdoor, Camping']=892986;
$modes['Outdoor, Dcor']=553788;
$modes['Outdoor, Heating & Lighting']=553778;
$modes['Outdoor, Furniture']=553824; 	
$modes['Camera, Top Selling']=513080;
$modes['Camera, Accessories']=172435;
$modes['Camera, Binoculars']=297842;

$modes['Camera, Camcorders']=172421;
$modes['Camera, Digital Cameras']=281052;
$modes['Camera, Film Cameras']=499106;
$modes['Camera, Frames & Albums']=499176;
$modes['Camera, Printers & Scanners']=499328;
$modes['Camera, Projectors']=525462;
$modes['Camera, Telescopes & Microscopes']=660408;
$modes['Computers, Top Selling']=565118;
$modes['Computers, AMD']=602286;
$modes['Computers, Apple']=565124;
$modes['Computers, HP']= 565120;
$modes['Computers, IBM']=603128;
$modes['Computers, Intel']=565122;
$modes['Computers, Sony']=565126;
$modes['Computers, Toshiba']=598398;
$modes['Tools, Top Selling']=468240;
$modes['Tools, Outlet']=527694;
$modes['Tools, Electrical']=495266;
$modes['Tools, Heating & Cooling']=495346;
$modes['Tools, Lighting']=495224;
$modes['Tools, Automotive']=553294;
$modes['Tools, Hand Tools']=551238;

$modes['Tools, Equipment']=551240;
$modes['Tools, Power Tools']=551236;
$modes['Tools, Models']=923468;
$modes['Tools, Hardware']=511228;
$modes['Tools, Lawn/Garden']=551242;
$modes['Tools, Accessories']=552262;
$modes['Tools, Air Tools']=552684;
$modes['Tools, Cordless Tools']=552738;
$modes['Tools, Sanders']=552876;

$modes['Tools, Saws']=552894;
$modes['Tools, Painting']=228899;

$modes['Electronics, Top Selling']=172282;
$modes['Electronics, Outlet']=301793;
$modes['Electronics, Accessories & Supplies']=281407;
$modes['Electronics, Car Accessories']=226184;
$modes['Electronics, Clocks & Clock Radios']=509280;

$modes['Electronics, Computer Add-Ons']=172455;
$modes['Electronics, DVD Players']=172514;
$modes['Electronics, Gadgets']=172517;
$modes['Electronics, GPS & Navigation']=172526;
$modes['Electronics, Handhelds & PDAs']=172594;
$modes['Electronics, Home Audio']=172531;
$modes['Electronics, Home Office']=172574;
$modes['Electronics, Home Video']=172592;

$modes['Electronics, Phones']=172606;
$modes['Electronics, Portable Audio & Video']=172623;
$modes['Electronics, Printers']=172635;
$modes['Electronics, TVs']=172659;
$modes['Electronics, VCRs & DVRs']=172669 ;	
$modes['Baby, Backpacks & Carriers']=542456;
$modes['Baby, Car Seats']=541560;

$modes['Baby, Strollers']=541562;
$modes['Baby, Travel Systems']=542442;
$modes['Baby, Playards']=542468;
$modes['Baby, Bedding']=541574;
$modes['Baby, Furniture']=541576;
$modes['Baby, Breast-feeding']=541568;
$modes['Baby, Bottle Feeding']=541566;
$modes['Baby, Solid Feeding']=541570;
$modes['Baby, Highchairs']=542302;

$modes['Baby, Play Centers']=548050;
$modes['Baby, Swings & Bouncers']=542470;
$modes['Baby, Toys: Birth - 12 months']=731816;
$modes['Baby, Toys: 12 - 24 months']=731876;
$modes['Baby, Toys: 2 years']=731924 ;
?>