<?php
// books first

$amazon_modes['All Products']='aps';
$amazon_modes['Baby']='baby';
$amazon_modes['Books']='books';
$amazon_modes['Camera &amp; Photo']='photo';
$amazon_modes['Computers']='pc-hardware';
$amazon_modes['DVDs']='dvd';
$amazon_modes['Electronics']='electronics';
$amazon_modes['Kitchen']='kitchen';
$amazon_modes['Magazines']='magazines';
$amazon_modes['Music']='music';
$amazon_modes['Music Downloads']='music-dd';
$amazon_modes['Classical Music']='classical';
$amazon_modes['Outdoor Living']='garden';
$amazon_modes['Restaurants']='restaurants';
$amazon_modes['Software']='software';
$amazon_modes['Tools']='tools';
$amazon_modes['Toys']='toys';
$amazon_modes['Travel']='travel';
$amazon_modes['VHS']='vhs';
$amazon_modes['Video Games']='videogames';

$amazon_modes['Movie Showtimes']='theatrical';
$amazon_modes['Cell Phones & Service']='wireless-phones';
$amazon_modes['Outlet']='outlet';
$amazon_modes['Auctions']='auction-redirect';
$amazon_modes['zShops']='fixed-price-redirec';
$amazon_modes['Sci. Supplies']='moc-scientific-supplies';
$amazon_modes['Med. Supplies']='moc-medical-supplies';
$amazon_modes['Indust. Suppl.']='moc-industrial-supplies';
$amazon_modes['Car Parts']='moc-cars';
$amazon_modes['Home Furnish.']='moc-home-furnishings';
$amazon_modes['Lifestyle']='moc-lifestyle';
$amazon_modes['Pet Toys']='moc-pet-toys';
$amazon_modes['Arts &amp; Hobbies']='moc-arts-hobby';

$amazon_browseid['Books, Top Selling']=1000;
$amazon_browseid['Books, Bargain']=45;

$amazon_browseid['Books, Audiocassettes']=44;
$amazon_browseid['Books, Audio CDs']=69724;
$amazon_browseid['Books, Business']=3;
$amazon_browseid['Books, Cooking']=6;
$amazon_browseid['Books, Home/Garden']=48;
$amazon_browseid['Books, Literature/Fiction']=17;
$amazon_browseid['Books, Nonfiction']=53;
$amazon_browseid['Books, Technical']=173507;
$amazon_browseid['Books, Romance']=23;

$amazon_browseid['Books, Sports']=26;
$amazon_browseid['Books, Childrens']=4;
$amazon_browseid['Books, Engineering']=13643;
$amazon_browseid['Books, Health']=10;
$amazon_browseid['Books, Reference']=21;
$amazon_browseid['Books, Science']=75;
$amazon_browseid['Books, Biographies']=2;
$amazon_browseid['Books, Computers/Internet']=5;
$amazon_browseid['Books, Entertainment']=86;

$amazon_browseid['Books, History']=9;
$amazon_browseid['Books, Law']=10777;
$amazon_browseid['Books, Mystery']=18;
$amazon_browseid['Books, Religion']=22;
$amazon_browseid['Books, SciFi/Fantasy']=25;
$amazon_browseid['Books, Travel']=27;
$amazon_browseid['Books, Arts & Photography']=1;
$amazon_browseid['Books, e-books']=551440;

$amazon_browseid['Books, Women\'s Fiction']=542654;

$amazon_browseid['Magazines, Top Selling']=599872;
$amazon_browseid['Magazines, Computer/Internet']=602324;
$amazon_browseid['Magazines, Family']=602330;
$amazon_browseid['Magazines, Games']=602336;
$amazon_browseid['Magazines, History']=602342;
$amazon_browseid['Magazines, Lifestyle']=602348;
$amazon_browseid['Magazines, Music']=602354;

$amazon_browseid['Magazines, Pets']=602360;
$amazon_browseid['Magazines, Espanol']=1040158;
$amazon_browseid['Magazines, Travel']=602370;
$amazon_browseid['Magazines, Arts']=602314;
$amazon_browseid['Magazines, Business']=602320;
$amazon_browseid['Magazines, Electronics']=602326;
$amazon_browseid['Magazines, Fashion']=602332;
$amazon_browseid['Magazines, Home/Garden']=602344;
$amazon_browseid['Magazines, Literary']=602350;

$amazon_browseid['Magazines, Newspapers']=1040160;
$amazon_browseid['Magazines, Religion']=602362;
$amazon_browseid['Magazines, Sport']=602366;
$amazon_browseid['Magazines, Womens']=602372;
$amazon_browseid['Magazines, Automotive']=602316;
$amazon_browseid['Magazines, Childrens']=602322;
$amazon_browseid['Magazines, Entertainment']=602328;
$amazon_browseid['Magazines, Food']= 602334;
$amazon_browseid['Magazines, Health']=602340;

$amazon_browseid['Magazines, International']=602346;
$amazon_browseid['Magazines, Mens']=602352;
$amazon_browseid['Magazines, News/Politics']=602358;
$amazon_browseid['Magazines, Science/Nature']=602364;
$amazon_browseid['Magazines, Teen']=602368; 	

$amazon_browseid['DVDs, Top Selling']=286723;
$amazon_browseid['DVDs, New & Future Releases']=404332;
$amazon_browseid['DVDs, Animation']=712256;

$amazon_browseid['DVDs, Classic']=163345;
$amazon_browseid['DVDs, Documentary']=508532;
$amazon_browseid['DVDs, Horror']=163396;
$amazon_browseid['DVDs, SciFi/Fantasy']=163431;
$amazon_browseid['DVDs, Television']=163450;
$amazon_browseid['DVDs, Action/Adventure']=163296;
$amazon_browseid['DVDs, Anime/Manga']=517956;
$amazon_browseid['DVDs, Comedy']=163357;
$amazon_browseid['DVDs, Drama']=163379;

$amazon_browseid['DVDs, Kids/Family']=163414;
$amazon_browseid['DVDs, Music Video']=163420;
$amazon_browseid['DVDs, Special Interest']=163448;
$amazon_browseid['DVDs, Military/War']=586156;
$amazon_browseid['DVDs, Mystery/Suspense']=512030;
$amazon_browseid['DVDs, Sports']=467970;
$amazon_browseid['DVDs, African-American Cinema']=538708;
$amazon_browseid['DVDs, International']=163313;
$amazon_browseid['DVDs, Boxed Sets']=501230;

$amazon_browseid['DVDs, Cult']=466674;
$amazon_browseid['DVDs, Gay & Lesbian']=301667;
$amazon_browseid['DVDs, Hong Kong Action']=464426;
$amazon_browseid['DVDs, Independents']=901596;
$amazon_browseid['DVDs, Musicals']=508528;
$amazon_browseid['DVDs, Westerns']=163312 ;

$amazon_browseid['Music, Top Selling']=301668;
$amazon_browseid['Music, New & Future Releases']=465672;
$amazon_browseid['Music, Classical']=85;
$amazon_browseid['Music, Dance/DJ']=7;
$amazon_browseid['Music, Pop']=37;
$amazon_browseid['Music, Rock']=40;
$amazon_browseid['Music, Alternative']=30;
$amazon_browseid['Music, Classic Rock']=67204;
$amazon_browseid['Music, Jazz']=34;

$amazon_browseid['Music, Rap']=38;
$amazon_browseid['Music, Soundtracks']=42;
$amazon_browseid['Music, Blues']=31;
$amazon_browseid['Music, Christian']=173429;
$amazon_browseid['Music, Country']=16;
$amazon_browseid['Music, Latin']=289122;
$amazon_browseid['Music, R/B']=39 	;

$amazon_browseid['Software, Top Selling']=491286;

$amazon_browseid['Software, Communication']=229636;
$amazon_browseid['Software, Graphics']=229614;
$amazon_browseid['Software, Linux']=290562;
$amazon_browseid['Software, Operating Sys']=229653;
$amazon_browseid['Software, Downloadable']=531448;
$amazon_browseid['Software, Utilities']=229672;
$amazon_browseid['Software, Business']=229535;
$amazon_browseid['Software, Education']=229563;
$amazon_browseid['Software, Home/Hobby']=229624;

$amazon_browseid['Software, Mac']=229643;
$amazon_browseid['Software, Finance']=229540;
$amazon_browseid['Software, Handhelds']=229663;
$amazon_browseid['Software, Video']=497022;
$amazon_browseid['Software, Childrens']=229548;
$amazon_browseid['Software, Games']=229575;
$amazon_browseid['Software, Language/Travel']=497026;
$amazon_browseid['Software, Networking']=229637;
$amazon_browseid['Software, Programming']=229667;

$amazon_browseid['Software, Web Dev']=497024 ;	

$amazon_browseid['VHS, Top Selling']=286721;
$amazon_browseid['VHS, New & Future Releases']=286747;
$amazon_browseid['VHS, Animation']=712260;
$amazon_browseid['VHS, Classic']=127;
$amazon_browseid['VHS, Documentary']=508530;
$amazon_browseid['VHS, Horror']=131;
$amazon_browseid['VHS, SciFi/Fantasy']=144;

$amazon_browseid['VHS, Television']=136;
$amazon_browseid['VHS, Action/Adventure']=141;
$amazon_browseid['VHS, Anime/Manga']=281300;
$amazon_browseid['VHS, Comedy']=128;
$amazon_browseid['VHS, Drama']=129;
$amazon_browseid['VHS, Kids/Family']=132;
$amazon_browseid['VHS, Music Video']=133;
$amazon_browseid['VHS, Special Interest']=135;
$amazon_browseid['VHS, Military/War']=586154;

$amazon_browseid['VHS, Mystery/Suspense']=512026;
$amazon_browseid['VHS, Sports']=169798;

$amazon_browseid['Video Games, Top Selling']=471280;
$amazon_browseid['Video Games, Game Cube']=541022;
$amazon_browseid['Video Games, Play Station 2']=301712;
$amazon_browseid['Video games, Game Boy']=229783;
$amazon_browseid['Video Games, Mac']=229647;
$amazon_browseid['Video Games, PC']=229575;

$amazon_browseid['Video Games, Game Boy Advance']=541020;
$amazon_browseid['Video Games, Xbox']=537504; 	

$amazon_browseid['Kitchen, Top Selling']=491864;
$amazon_browseid['Kitchen, Outlet']=526844;
$amazon_browseid['Kitchen, Coffee/Tea']=289742;
$amazon_browseid['Kitchen, Cookware']=289814;
$amazon_browseid['Kitchen, Appliances']=289913;
$amazon_browseid['Kitchen, Baking']=289668;

$amazon_browseid['Kitchen, Housewares']=510080;
$amazon_browseid['Kitchen, Tableware']=289891;
$amazon_browseid['Kitchen, Bar Tools']=289728;
$amazon_browseid['Kitchen, Gadgets']=289754;
$amazon_browseid['Kitchen, Knives']=289851; 

$amazon_browseid['Toys, Top Selling']=491290;
$amazon_browseid['Toys, Crafts']=171859;
$amazon_browseid['Toys, Dolls']=171569;

$amazon_browseid['Toys, Games']=171689;
$amazon_browseid['Toys, Outdoor']=171960;
$amazon_browseid['Toys, Action Figures']=171662;
$amazon_browseid['Toys, Bikes']=569472;
$amazon_browseid['Toys, Electronics']=720366;
$amazon_browseid['Toys, Stuffed Animals']=171992;
$amazon_browseid['Toys, Learning']=171911;
$amazon_browseid['Toys, Building']=171814;
$amazon_browseid['Toys, Furniture']=172790;

$amazon_browseid['Toys, Puzzles']=171744;
$amazon_browseid['Toys, Vehicles']=171600; 

$amazon_browseid['Outdoor, Top Selling']=468250;
$amazon_browseid['Outdoor, Outlet']=526814 ;
$amazon_browseid['Outdoor, Gifts']=553648;
$amazon_browseid['Outdoor, Lawn/Garden Tools']=915484;
$amazon_browseid['Outdoor, Pest Control']=553844;
$amazon_browseid['Outdoor, Birding']=553632;

$amazon_browseid['Outdoor, Grills']=553760;
$amazon_browseid['Outdoor, Camping']=892986;
$amazon_browseid['Outdoor, Dcor']=553788;
$amazon_browseid['Outdoor, Heating & Lighting']=553778;
$amazon_browseid['Outdoor, Furniture']=553824;

$amazon_browseid['Camera, Top Selling']=513080;
$amazon_browseid['Camera, Accessories']=172435;
$amazon_browseid['Camera, Binoculars']=297842;

$amazon_browseid['Camera, Camcorders']=172421;
$amazon_browseid['Camera, Digital Cameras']=281052;
$amazon_browseid['Camera, Film Cameras']=499106;
$amazon_browseid['Camera, Frames & Albums']=499176;
$amazon_browseid['Camera, Printers & Scanners']=499328;
$amazon_browseid['Camera, Projectors']=525462;
$amazon_browseid['Camera, Telescopes & Microscopes']=660408;


$amazon_browseid['Computers, Top Selling']=565118;
$amazon_browseid['Computers, AMD']=602286;
$amazon_browseid['Computers, Apple']=565124;
$amazon_browseid['Computers, HP']= 565120;
$amazon_browseid['Computers, IBM']=603128;
$amazon_browseid['Computers, Intel']=565122;
$amazon_browseid['Computers, Sony']=565126;
$amazon_browseid['Computers, Toshiba']=598398;


$amazon_browseid['Tools, Top Selling']=468240;
$amazon_browseid['Tools, Outlet']=527694;
$amazon_browseid['Tools, Electrical']=495266;
$amazon_browseid['Tools, Heating & Cooling']=495346;
$amazon_browseid['Tools, Lighting']=495224;
$amazon_browseid['Tools, Automotive']=553294;
$amazon_browseid['Tools, Hand Tools']=551238;

$amazon_browseid['Tools, Equipment']=551240;
$amazon_browseid['Tools, Power Tools']=551236;
$amazon_browseid['Tools, Models']=923468;
$amazon_browseid['Tools, Hardware']=511228;
$amazon_browseid['Tools, Lawn/Garden']=551242;
$amazon_browseid['Tools, Accessories']=552262;
$amazon_browseid['Tools, Air Tools']=552684;
$amazon_browseid['Tools, Cordless Tools']=552738;
$amazon_browseid['Tools, Sanders']=552876;

$amazon_browseid['Tools, Saws']=552894;
$amazon_browseid['Tools, Painting']=228899;


$amazon_browseid['Electronics, Top Selling']=172282;
$amazon_browseid['Electronics, Outlet']=301793;
$amazon_browseid['Electronics, Accessories & Supplies']=281407;
$amazon_browseid['Electronics, Car Accessories']=226184;
$amazon_browseid['Electronics, Clocks & Clock Radios']=509280;

$amazon_browseid['Electronics, Computer Add-Ons']=172455;
$amazon_browseid['Electronics, DVD Players']=172514;
$amazon_browseid['Electronics, Gadgets']=172517;
$amazon_browseid['Electronics, GPS & Navigation']=172526;
$amazon_browseid['Electronics, Handhelds & PDAs']=172594;
$amazon_browseid['Electronics, Home Audio']=172531;
$amazon_browseid['Electronics, Home Office']=172574;
$amazon_browseid['Electronics, Home Video']=172592;

$amazon_browseid['Electronics, Phones']=172606;
$amazon_browseid['Electronics, Portable Audio & Video']=172623;
$amazon_browseid['Electronics, Printers']=172635;
$amazon_browseid['Electronics, TVs']=172659;
$amazon_browseid['Electronics, VCRs & DVRs']=172669 ;	

$amazon_browseid['Baby, Backpacks & Carriers']=542456;
$amazon_browseid['Baby, Car Seats']=541560;

$amazon_browseid['Baby, Strollers']=541562;
$amazon_browseid['Baby, Travel Systems']=542442;
$amazon_browseid['Baby, Playards']=542468;
$amazon_browseid['Baby, Bedding']=541574;
$amazon_browseid['Baby, Furniture']=541576;
$amazon_browseid['Baby, Breast-feeding']=541568;
$amazon_browseid['Baby, Bottle Feeding']=541566;
$amazon_browseid['Baby, Solid Feeding']=541570;
$amazon_browseid['Baby, Highchairs']=542302;

$amazon_browseid['Baby, Play Centers']=548050;
$amazon_browseid['Baby, Swings & Bouncers']=542470;
$amazon_browseid['Baby, Toys: Birth - 12 months']=731816;
$amazon_browseid['Baby, Toys: 12 - 24 months']=731876;
$amazon_browseid['Baby, Toys: 2 years']=731924 ;
?>