<?php /* Smarty version 2.6.26, created on 2012-06-07 17:42:35
         compiled from firststep.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'translate', 'firststep.htm', 12, false),array('modifier', 'htmlsafe', 'firststep.htm', 192, false),array('modifier', 'cat', 'firststep.htm', 274, false),array('function', 'conditionalOutput', 'firststep.htm', 37, false),array('function', 'switchedOutput', 'firststep.htm', 95, false),)), $this); ?>
<!-- firststep.html -->
<div class="i-col-container">
	<div class="i-col80">
		<div style="padding-right: 20px;">
<form action="<?php echo $this->_tpl_vars['formLink']; ?>
" method="post" enctype="multipart/form-data" name="form">
<?php $this->assign('invalidFieldMarkup', ' style="color: #FF0000"'); ?>

<?php if (! $this->_tpl_vars['fatalError']): ?>
	<?php if (! $this->_tpl_vars['profileCreated']): ?>
		<?php if (! $this->_tpl_vars['profileCreated']): ?>
	<h1><?php echo ((is_array($_tmp='install_step2_title')) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); ?>
</h1>
		<?php else: ?>
    <h1><?php echo ((is_array($_tmp='install_step2_finish')) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); ?>
</h1>
		<?php endif; ?>
	<br>
        <?php if ($this->_tpl_vars['errorStr']): ?>
	<p<?php echo $this->_tpl_vars['invalidFieldMarkup']; ?>
><?php echo $this->_tpl_vars['errorStr']; ?>
</p>
        <?php endif; ?>
        
        <?php if ($this->_tpl_vars['infoStr']): ?>
	<p><?php echo $this->_tpl_vars['infoStr']; ?>
</p>
        <?php endif; ?>

	<table border="0" cellpadding="5" cellspacing="0" class="settings-table" style="width: 100%;">
		<tr>
			<td colspan="2" class="form-required-field"><?php echo $this->_tpl_vars['waStrings']['forms_req_fields']; ?>
</td>
		</tr>
		<tr>
			<td colspan="2">&nbsp;</td>
		</tr>
<!-- MySQL Settings-->
		<tr style="background-color: #eee;">
			<td colspan="2">&nbsp;</td>
		</tr>
		<tr style="background-color: #eee;">
			<td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'HOST','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
				<?php echo ((is_array($_tmp='addserv_gr2_opt1')) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); ?>
:&nbsp;*
			</td>
			<td>
				<input name="serverData[HOST]" type="text" class="big-control" value="<?php echo $this->_tpl_vars['serverData']['HOST']; ?>
">
			</td>
		</tr>
		<tr style="background-color: #eee;">
			<td>&nbsp;</td>
			<td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'PORT','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
				<?php echo ((is_array($_tmp='addserv_gr2_opt3')) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); ?>
:&nbsp;
            	<input name="serverData[PORT]" type="text" class="control" value="<?php echo $this->_tpl_vars['serverData']['PORT']; ?>
">
            </td>
		</tr>
		<tr style="background-color: #eee;">
			<td>&nbsp;</td>
			<td class="comment"><?php echo ((is_array($_tmp='addserv_gr2_desc1')) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); ?>
</td>
		</tr>
		<tr style="background-color: #eee;">
			<td>&nbsp;</td>
			<td class="comment"><?php echo ((is_array($_tmp='addserv_gr2_desc3')) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); ?>
</td>
		</tr>
<!-- Server name -->		
		<tr style="background-color: #eee;">
			<td>&nbsp;</td>
			<td>&nbsp;
				<input type="hidden" name="serverData[SERVER_NAME]" value="<?php echo $this->_tpl_vars['serverData']['SERVER_NAME']; ?>
">
				<input type="hidden" name="action" value="<?php echo $this->_tpl_vars['action']; ?>
">
				<input type="hidden" name="edited" value="1"> 
				<input type="hidden" name="languagesPacked" value="<?php echo $this->_tpl_vars['languagesPacked']; ?>
">
				<input type="hidden" name="languageToDelete">
			</td>
		</tr>

        <tr style="background-color: #eee;"> 
			<td class="nobr"
			<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[DB_CREATE_OPTIONS][DATABASE_USER_EXISTING]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>

			<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ADMIN_USERNAME','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
			<?php echo $this->_tpl_vars['waStrings']['dbmgm_gr2_username']; ?>
:  *</td>
			<td><input name="hostData[DB_CREATE_OPTIONS][DATABASE_USER_EXISTING]" type="text" class="big-control" value="<?php echo $this->_tpl_vars['hostData']['DB_CREATE_OPTIONS']['DATABASE_USER_EXISTING']; ?>
"></td>
		</tr>
		<tr style="background-color: #eee;"> 
			<td class="nobr"<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[DB_CREATE_OPTIONS][PASSWORD_EXISTING]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ADMIN_PASSWORD','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr2_pwd']; ?>
:&nbsp;*</td>
			<td><input name="hostData[DB_CREATE_OPTIONS][PASSWORD_EXISTING]" type="text" class="big-control" value="<?php echo $this->_tpl_vars['hostData']['DB_CREATE_OPTIONS']['PASSWORD_EXISTING']; ?>
"></td>
		</tr>
		<tr style="background-color: #eee;">
			<td colspan="2">&nbsp;</td>
		</tr>

		<tr style="background-color: #fff;">
			<td colspan="2">&nbsp;</td>
		</tr>
		<tr> 
			<td colspan="2" style="background-color: #fff;">
				<table border="0">
					
			        <tr>
						<td style="padding: 0px;">
							<input type="radio" onClick="onSelectFocus('use_dbname')" name="hostData[DB_CREATE_OPTIONS][CREATE_OPTION]" value="use" id="use" <?php echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['hostData']['DB_CREATE_OPTIONS']['CREATE_OPTION'],'true_val' => 'use'), $this);?>
>
						</td>
						<td colspan="2" style="padding: 0px;" class="nobr" <?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[DB_CREATE_OPTIONS][CREATE_OPTION]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
							<label for="use"><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr2_sel2']; ?>
</label>:
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[DB_CREATE_OPTIONS][DATABASE_EXISTING]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
							<?php echo $this->_tpl_vars['waStrings']['dbmgm_gr2_dbname']; ?>
:&nbsp;*&nbsp;</td>
						<td>
							<input name="hostData[DB_CREATE_OPTIONS][DATABASE_EXISTING]"  id="use_dbname" type="text" class="big-control" value="<?php echo $this->_tpl_vars['hostData']['DB_CREATE_OPTIONS']['DATABASE_EXISTING']; ?>
" onfocus="onFocusSelect('use', 'new');">
						</td>
					</tr>
					<tr>
						<td colspan="3">&nbsp;</td>
					</tr>
					<tr>
						<td style="padding: 0px;" width="20">
							<input type="radio" onClick="onSelectFocus('new_dbname')" name="hostData[DB_CREATE_OPTIONS][CREATE_OPTION]" value="new" id="new" <?php echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['hostData']['DB_CREATE_OPTIONS']['CREATE_OPTION'],'true_val' => 'new'), $this);?>
>
						</td>
						<td colspan="2" style="padding: 0px;" width="100%" class="nobr" <?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[DB_CREATE_OPTIONS][CREATE_OPTION]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
							<label for="new"><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr2_sel1']; ?>
</label>:
						</td>
					</tr>
		
					<tr>
						<td>&nbsp;</td>
						<td width="30%" <?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[DB_CREATE_OPTIONS][DATABASE_NEW]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
							<?php echo $this->_tpl_vars['waStrings']['dbmgm_gr2_dbname']; ?>
:&nbsp;*&nbsp;
						</td>
						<td width="70%">
							<input name="hostData[DB_CREATE_OPTIONS][DATABASE_NEW]" id="new_dbname" type="text" class="big-control" value="<?php echo $this->_tpl_vars['hostData']['DB_CREATE_OPTIONS']['DATABASE_NEW']; ?>
" onfocus="onFocusSelect('new', 'use');">
						</td>
					</tr>
					<tr>
						<td>&nbsp;</td>
						<td colspan="2" class=comment>
							<b><?php echo $this->_tpl_vars['waStrings']['lbl_form_note']; ?>
</b>: <?php echo $this->_tpl_vars['waStrings']['addserv_gr5_note1']; ?>

						</td>
					</tr>
					
				</table>
			</td>
		</tr>
		<tr style="background-color: #fff;">
			<td colspan="2">&nbsp;</td>
		</tr>
        <tr>
			<td colspan="2">
				<div class="formSection"><?php echo $this->_tpl_vars['waStrings']['cmn_set_sys_name']; ?>
</div>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
            <td>&nbsp;</td>
		</tr>
		<tr>
			<td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'WBS_INSTALL_PATH','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
				<?php echo $this->_tpl_vars['waStrings']['wbs_install_path']; ?>
:&nbsp;
			</td>
            <td>
            	<input name="commondata[WBS_INSTALL_PATH]" value="<?php echo $this->_tpl_vars['commondata']['WBS_INSTALL_PATH']; ?>
" type="text" class="control">
           	</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td class="comment">
				<p class="comment"><?php echo $this->_tpl_vars['waStrings']['wbs_install_path_desc']; ?>
</p>
			</td>
		</tr>
		<tr>
			<td>&nbsp;</td>
			<td>&nbsp;</td>
		</tr>
                  <!--             -->
		<tr>
			<td colspan="2">
				<div class="formSection"><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_name']; ?>
</div>
			</td>
		</tr>
		<tr>
            <td colspan="2" class="comment">
	      <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_desc1']; ?>

	      </td>
          </tr>
          <tr>
            <td>&nbsp;</td>
            <td>&nbsp;</td>
          </tr>


          <tr>
            <td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[FIRSTLOGIN][LOGINNAME]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
              <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_login']; ?>
:&nbsp;*</td>
            <td>
             
              <input name="hostData[FIRSTLOGIN][LOGINNAME]" type="text" class="control" style="font-weight: bold;" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['hostData']['FIRSTLOGIN']['LOGINNAME'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); ?>
" maxlength="20">
             
            </td>
          </tr>
          <tr>
            <td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[FIRSTLOGIN][PASSWORD1]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
              <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_pwd']; ?>
:&nbsp;*</td>
            <td>
           <input name="hostData[FIRSTLOGIN][PASSWORD1]" type="text" class="control" style="font-weight: bold;" maxlength="50" value="<?php echo $this->_tpl_vars['hostData']['FIRSTLOGIN']['PASSWORD1']; ?>
"></td>
             
          </tr>
          <tr>
            <td colspan="2" class="comment"><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_desc2']; ?>

			    </td>
          </tr>


          <tr>
            <td colspan="2">&nbsp;
            </td>
          </tr>

 
           <tr>
            <td height="24"<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[FIRSTLOGIN][EMAIL]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
              <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_email']; ?>
:&nbsp;*
              </td>
            <td>
             
              <input name="hostData[FIRSTLOGIN][EMAIL]" type="text" class="control" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['hostData']['FIRSTLOGIN']['EMAIL'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); ?>
" maxlength="50">
            </td>
          </tr>
          


          <tr>
            <td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[FIRSTLOGIN][FIRSTNAME]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
              <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_firstname']; ?>
:&nbsp;*</td>
            <td>
 
              <input name="hostData[FIRSTLOGIN][FIRSTNAME]" type="text" class="control" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['hostData']['FIRSTLOGIN']['FIRSTNAME'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); ?>
" maxlength="20">

            </td>
          </tr>
          <tr>
            <td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[FIRSTLOGIN][LASTNAME]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
              <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_lastname']; ?>
:&nbsp;*</td>
            <td>
             
              <input name="hostData[FIRSTLOGIN][LASTNAME]" type="text" class="control" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['hostData']['FIRSTLOGIN']['LASTNAME'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); ?>
" maxlength="24">

            </td>
          </tr>


          <tr>
            <td<?php echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => "hostData[FIRSTLOGIN][COMPANYNAME]",'text' => $this->_tpl_vars['invalidFieldMarkup']), $this);?>
>
              <?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_company']; ?>
:&nbsp;*</td>
              <td>
 
              <input name="hostData[FIRSTLOGIN][COMPANYNAME]" type="text" class="control" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['hostData']['FIRSTLOGIN']['COMPANYNAME'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); ?>
" maxlength="20">

            </td>
          </tr>


          <tr>
            <td colspan="2">
                     <input type="submit" name="savebtn" value="<?php echo $this->_tpl_vars['buttonCaption']; ?>
">
            </td>
          </tr>
        </table>
   <?php else: ?>
   
<div class="i-wrapper">
	<h2><?php echo $this->_tpl_vars['title']; ?>
</h2><br>
	<div  style="background:#eeeeee;padding:20px;width:500px;">
		<h2><?php echo $this->_tpl_vars['waStrings']['install_link_db']; ?>
</h2>
		<br>
		<p><b><a href="#" name=loginURL><script language="JavaScript" type="text/javascript">makeLinkURL( 5, '<?php echo $this->_tpl_vars['loginURL']; ?>
', 'loginURL', true );</script></a></b></p>
		<p class="comment"><?php echo $this->_tpl_vars['waStrings']['install_link_db_comment']; ?>
</p>
		<br>
		<!-- <p><?php echo $this->_tpl_vars['waStrings']['install_work_dbkey']; ?>
:  <b><?php echo ((is_array($_tmp=((is_array($_tmp=' ')) ? $this->_run_mod_handler('cat', true, $_tmp, $this->_tpl_vars['DB_KEY']) : smarty_modifier_cat($_tmp, $this->_tpl_vars['DB_KEY'])))) ? $this->_run_mod_handler('cat', true, $_tmp, ' ') : smarty_modifier_cat($_tmp, ' ')); ?>
</b><br> -->
		<p><?php echo $this->_tpl_vars['waStrings']['install_link_login']; ?>
&nbsp;<b><?php echo $this->_tpl_vars['hostData']['FIRSTLOGIN']['FIRSTNAME']; ?>
&nbsp;<?php echo $this->_tpl_vars['hostData']['FIRSTLOGIN']['LASTNAME']; ?>
</b>&nbsp;<?php echo $this->_tpl_vars['waStrings']['install_link_login_use']; ?>
:</p>
		<p><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_login']; ?>
:&nbsp;<b><?php echo ((is_array($_tmp=((is_array($_tmp=' ')) ? $this->_run_mod_handler('cat', true, $_tmp, $this->_tpl_vars['hostData']['FIRSTLOGIN']['LOGINNAME']) : smarty_modifier_cat($_tmp, $this->_tpl_vars['hostData']['FIRSTLOGIN']['LOGINNAME'])))) ? $this->_run_mod_handler('cat', true, $_tmp, ' ') : smarty_modifier_cat($_tmp, ' ')); ?>
</b></p>
		<p><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_pwd']; ?>
:&nbsp;<b><?php echo ((is_array($_tmp=((is_array($_tmp=' ')) ? $this->_run_mod_handler('cat', true, $_tmp, $this->_tpl_vars['hostData']['FIRSTLOGIN']['PASSWORD1']) : smarty_modifier_cat($_tmp, $this->_tpl_vars['hostData']['FIRSTLOGIN']['PASSWORD1'])))) ? $this->_run_mod_handler('cat', true, $_tmp, ' ') : smarty_modifier_cat($_tmp, ' ')); ?>
</b></p>
		<hr size="1">
		<p><?php echo $this->_tpl_vars['waStrings']['install_link_login']; ?>
&nbsp;<b>Administrator</b>&nbsp;<?php echo $this->_tpl_vars['waStrings']['install_link_login_use']; ?>
:</p>
		<p><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_login']; ?>
:&nbsp;<b>ADMINISTRATOR</b></p>
		<p><?php echo $this->_tpl_vars['waStrings']['dbmgm_gr5_pwd']; ?>
:&nbsp;<b><?php echo ((is_array($_tmp=((is_array($_tmp=' ')) ? $this->_run_mod_handler('cat', true, $_tmp, $this->_tpl_vars['hostData']['FIRSTLOGIN']['PASSWORD1']) : smarty_modifier_cat($_tmp, $this->_tpl_vars['hostData']['FIRSTLOGIN']['PASSWORD1'])))) ? $this->_run_mod_handler('cat', true, $_tmp, ' ') : smarty_modifier_cat($_tmp, ' ')); ?>
</b></p>
		<p class="comment"><?php echo $this->_tpl_vars['waStrings']['admin_link_comment']; ?>
</p>
	</div>
	<div style="padding:20px;">
		<h2><?php echo $this->_tpl_vars['waStrings']['install_link_wba']; ?>
</h2><!-- <strong>WebAsyst Administrator</strong> -->
		<br>
		<p><b><a href="#" name=adminURL><script language="JavaScript" type="text/javascript">makeLinkURL( 5, '<?php echo $this->_tpl_vars['adminURL']; ?>
', 'adminURL', true )</script></a></b></p>
		<p class="comment"><?php echo $this->_tpl_vars['waStrings']['install_link_wba_comment']; ?>
</p>
		<br>
		<br>
	<?php if ($this->_tpl_vars['htaccessReplaced']): ?>
		<p><b><font color="red"><?php echo $this->_tpl_vars['waStrings']['wbs_user_htaccess']; ?>
</font></b></p>
		<br>
	<?php endif; ?>
		<p><b><font color="green"><?php echo $this->_tpl_vars['waStrings']['install_finish_notice']; ?>
</font></b></p>
	</div>
</div>
        <?php endif; ?>
   <?php endif; ?>
  </form>
		</div>
	</div>


	<div class="i-col20">
		<div class="i-colorbord i-p-padd">
			<div class="steps">
				<?php echo $this->_tpl_vars['step']; ?>

			</div>
		</div>
	</div>
</div>


<script type="text/javascript">
<!--
onLoad = function()
{
	<?php if ($this->_tpl_vars['invalidField']): ?>
	<?php if ($this->_tpl_vars['invalidField'] == 'ADMIN_USERNAME'): ?>
		if(focusControl('hostData[DB_CREATE_OPTIONS][DATABASE_USER_EXISTING]'))return;
	<?php endif; ?>
	
//	hostData[DB_CREATE_OPTIONS][DATABASE_NEW]
	if(focusControl('<?php echo $this->_tpl_vars['invalidField']; ?>
'))return;
	if(focusControl('hostdata[<?php echo $this->_tpl_vars['invalidField']; ?>
]'))return;
	if(focusControl('serverdata[<?php echo $this->_tpl_vars['invalidField']; ?>
]'))return;
	alert('<?php echo $this->_tpl_vars['invalidField']; ?>
');	
	<?php else: ?>
	<?php endif; ?>
	
}
//alert(document.body.onload);
onLoad();
//-->
</script>
<!-- /firststep.html -->