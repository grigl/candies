<?php /* Smarty version 2.6.26, created on 2012-06-07 17:48:17
         compiled from addmodlanguage.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'conditionalOutput', 'addmodlanguage.htm', 24, false),array('function', 'switchedOutput', 'addmodlanguage.htm', 73, false),array('function', 'html_options', 'addmodlanguage.htm', 93, false),array('modifier', 'htmlsafe', 'addmodlanguage.htm', 27, false),)), $this); ?>
<!-- addmodlanguage.html -->
<?php echo '<form action="'; 
 echo $this->_tpl_vars['formLink']; 
 echo '" method="post" enctype="multipart/form-data" name="form"><h2 class="page-title"><a href="'; 
 echo @PAGE_DB_LANGUAGES; 
 echo '">'; 
 echo $this->_tpl_vars['waStrings']['lll_page_title']; 
 echo '</a> &raquo; '; 
 echo $this->_tpl_vars['pageName']; 
 echo '</h2><br>'; 
 $this->assign('invalidFieldMarkup', ' style="color: #FF0000" '); 
 echo ''; 
 if ($this->_tpl_vars['errorStr']): 
 echo '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td'; 
 echo $this->_tpl_vars['invalidFieldMarkup']; 
 echo '>'; 
 echo $this->_tpl_vars['errorStr']; 
 echo '</td></tr><tr><td colspan=2>&nbsp;</td></tr></table>'; 
 endif; 
 echo ''; 
 if (! $this->_tpl_vars['fatalError']): 
 echo '<table width="100%" border="0" cellpadding="1" cellspacing="0"><tr><td bgcolor="#FFFFFF">'; 
 if (! $this->_tpl_vars['showMessages']): 
 echo '<table border="0" cellpadding="0" cellspacing="0"><tr><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ID','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['llli_id']; 
 echo ':&nbsp;*&nbsp;</td><td>'; 
 if ($this->_tpl_vars['action'] == 'new'): 
 echo '<input name="langData[ID]" type="text" class="control" value="'; 
 echo ((is_array($_tmp=$this->_tpl_vars['langData']['ID'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); 
 echo '" style="width: 100"></td>'; 
 else: 
 echo ''; 
 echo $this->_tpl_vars['lang']; 
 echo '<input name="langData[ID]" type="hidden" value="'; 
 echo ((is_array($_tmp=$this->_tpl_vars['langData']['ID'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); 
 echo '">'; 
 endif; 
 echo '</tr><tr><td>&nbsp;</td><td class="comment">'; 
 echo $this->_tpl_vars['waStrings']['llli_desc1']; 
 echo '</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'NAME','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['llli_name']; 
 echo ':&nbsp;*&nbsp;</td><td><input name="langData[NAME]" type="text" class="control" value="'; 
 echo ((is_array($_tmp=$this->_tpl_vars['langData']['NAME'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); 
 echo '" style="width: 200"></td></tr><tr><td>&nbsp;</td><td class="comment">'; 
 echo $this->_tpl_vars['waStrings']['llli_desc2']; 
 echo '</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ENCODING','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['llli_encoding']; 
 echo ':&nbsp;*&nbsp;</td><td><input name="langData[ENCODING]" type="text" class="control" value="'; 
 echo ((is_array($_tmp=$this->_tpl_vars['langData']['ENCODING'])) ? $this->_run_mod_handler('htmlsafe', true, $_tmp, true, true) : smarty_modifier_htmlsafe($_tmp, true, true)); 
 echo '" style="width: 200"></td></tr><tr><td>&nbsp;</td><td class="comment">'; 
 echo $this->_tpl_vars['waStrings']['llli_desc3']; 
 echo '</td></tr><tr><td colspan="2"><input name="edited" type="hidden" value="1"><input name="action" type="hidden" value="'; 
 echo $this->_tpl_vars['action']; 
 echo '"><input name="lang" type="hidden" value="'; 
 echo $this->_tpl_vars['lang']; 
 echo '">&nbsp;&nbsp;</td></tr>'; 
 if ($this->_tpl_vars['action'] == 'new'): 
 echo '<tr><td colspan=2><p>'; 
 echo $this->_tpl_vars['waStrings']['llli_desc4']; 
 echo '<p>&nbsp;</td></tr><tr><td align=right><input type=radio name="createopt" value=2 '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['createopt'],'true_val' => 2), $this);
 echo '></td><td><table border=0 cellpadding=0 cellspacing=0><tr><td>'; 
 echo $this->_tpl_vars['waStrings']['llli_desc5']; 
 echo '&nbsp;</td></tr></table></td></tr><tr><td colspan=2>&nbsp;</td></tr><tr><td align=right><input type=radio name="createopt" value=0 '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['createopt'],'true_val' => 0), $this);
 echo '></td><td><table border=0 cellpadding=0 cellspacing=0><tr><td>'; 
 echo $this->_tpl_vars['waStrings']['llli_from_exist']; 
 echo ': &nbsp;</td><td><select name="copy_lang_id" class="control" onChange="setCreateOpt(0)">'; 
 echo smarty_function_html_options(array('values' => $this->_tpl_vars['lang_ids'],'selected' => $this->_tpl_vars['copy_lang_id'],'output' => $this->_tpl_vars['lang_names']), $this);
 echo '</select></td></tr></table></td></tr><tr><td colspan=2>&nbsp;</td></tr><tr><td align=right valign=top><input type=radio name="createopt" value=1 '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['createopt'],'true_val' => 1), $this);
 echo '></td><td><table border=0 cellpadding=2 cellspacing=0 width=500><tr><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'FILE','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['llli_from_file']; 
 echo ':&nbsp;<input type=file name="importfile" style="width: 200px"  onChange="setCreateOpt(1)"></td></tr><tr><td>&nbsp;</td></tr><tr><td class=smallFont><b>'; 
 echo $this->_tpl_vars['waStrings']['lbl_form_note']; 
 echo '</b>: '; 
 echo $this->_tpl_vars['waStrings']['llli_note']; 
 echo '<blockquote>'; 
 echo $this->_tpl_vars['waStrings']['llli_app_id']; 
 echo '<br>'; 
 echo $this->_tpl_vars['waStrings']['llli_string_id']; 
 echo '<br>'; 
 echo $this->_tpl_vars['waStrings']['llli_group']; 
 echo '<br>'; 
 echo $this->_tpl_vars['waStrings']['llli_str_desc']; 
 echo '<br>'; 
 echo $this->_tpl_vars['waStrings']['llli_str_value']; 
 echo '</blockquote></td></tr></table></td></tr><tr><td colspan=2>&nbsp;</td></tr><tr><td align=right><input type="checkbox" name="replacelocfiles" value=1 '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['replacelocfiles'],'true_val' => 1), $this);
 echo '></td><td>'; 
 echo $this->_tpl_vars['waStrings']['llli_str_replace']; 
 echo '</td></tr>'; 
 endif; 
 echo '<tr><td colspan=2>&nbsp;<br><br><br></td></tr><tr><td colspan="2"><table border="0" cellpadding="0" cellspacing="0" width="100%"><tr><td>'; 
 if ($this->_tpl_vars['action'] == 'edit'): 
 echo '<input type="submit" name="savebtn" value="'; 
 echo $this->_tpl_vars['waStrings']['btn_save']; 
 echo '"> &nbsp; <input name="cancelbtn" type="submit" value="'; 
 echo $this->_tpl_vars['waStrings']['btn_cancel']; 
 echo '"> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;  &nbsp; &nbsp;'; 
 else: 
 echo '<input type="submit" name="savebtn" value="'; 
 echo $this->_tpl_vars['waStrings']['btn_add']; 
 echo '"> &nbsp; <input name="cancelbtn" type="submit" value="'; 
 echo $this->_tpl_vars['waStrings']['btn_cancel']; 
 echo '">'; 
 endif; 
 echo '</td><td align=right>'; 
 if ($this->_tpl_vars['action'] == 'edit' && $this->_tpl_vars['delBtnVisible']): 
 echo '<input type="submit" name="deletebtn" value="'; 
 echo $this->_tpl_vars['waStrings']['llli_btn_delete']; 
 echo '" onClick="return confirm( \''; 
 echo $this->_tpl_vars['waStrings']['llli_req_delete']; 
 echo '\' );">'; 
 endif; 
 echo '</td></tr></table></td></tr></table>'; 
 else: 
 echo '<table cellpadding=2 cellspacing=0 border=0><tr><td>&nbsp;</td></tr><tr><td>'; 
 echo $this->_tpl_vars['messageStack']; 
 echo '</td></tr><tr><td><br><br><input name="cancelbtn" type="submit" value="OK"></td></tr></table>'; 
 endif; 
 echo '</td></tr></table>'; 
 else: 
 echo '<input name="cancelbtn" type="submit" value="'; 
 echo $this->_tpl_vars['waStrings']['btn_cancel']; 
 echo '">'; 
 endif; 
 echo '<input type=hidden name=lang_id value="'; 
 echo $this->_tpl_vars['lang_id']; 
 echo '"><input type=hidden name=app_id value="'; 
 echo $this->_tpl_vars['app_id']; 
 echo '"><input type=hidden name=type_id value="'; 
 echo $this->_tpl_vars['type_id']; 
 echo '"></form>'; ?>

<!-- here -->
<script type="text/javascript">
<!--
function setCreateOpt( opt )
{
	thisForm = document.forms[0];
	for ( i = 0; i < thisForm.elements.length; i++ ){
		if (thisForm.elements[i].type == 'radio')
			if ( thisForm.elements[i].name == "createopt" && thisForm.elements[i].value == opt ) {
				thisForm.elements[i].checked = true;
				break;
			}
	}
}
document.body.onload = function(){focusControl(<?php if ($this->_tpl_vars['action'] == 'new'): ?>'langData[ID]'<?php else: ?>'langData[NAME]'<?php endif; ?>);};
//-->
</script>
<!-- /addmodlanguage.html -->