<?php /* Smarty version 2.6.26, created on 2012-06-07 17:46:50
         compiled from addmodserver.htm */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'nl2br', 'addmodserver.htm', 12, false),array('function', 'conditionalOutput', 'addmodserver.htm', 27, false),array('function', 'switchedOutput', 'addmodserver.htm', 118, false),)), $this); ?>
<!-- addmodserver.html -->
<?php echo '<form action="'; 
 echo $this->_tpl_vars['formLink']; 
 echo '" method="post" enctype="multipart/form-data" name="form">'; 
 $this->assign('invalidFieldMarkup', ' style="color: #FF0000" '); 
 echo ''; 
 if (! $this->_tpl_vars['fatalError']): 
 echo '<h2 class="page-title">'; 
 if ($this->_tpl_vars['multiDBKEY']): 
 echo '<a href="'; 
 echo @PAGE_DB_SQLSERVERS; 
 echo '">'; 
 echo $this->_tpl_vars['waStrings']['sqls_page_title']; 
 echo '</a> &raquo; '; 
 endif; 
 echo ''; 
 echo $this->_tpl_vars['pageHeader']; 
 echo '</h2><br>'; 
 if ($this->_tpl_vars['action'] == edit && $this->_tpl_vars['multiDBKEY']): 
 echo '<h2 class="page-title">'; 
 echo $this->_tpl_vars['waStrings']['addserv_header']; 
 echo ' '; 
 echo $this->_tpl_vars['serverData']['SERVER_NAME']; 
 echo '</h2><br>'; 
 endif; 
 echo ''; 
 if ($this->_tpl_vars['errorStr']): 
 echo '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td'; 
 echo $this->_tpl_vars['invalidFieldMarkup']; 
 echo '>'; 
 echo ((is_array($_tmp=$this->_tpl_vars['errorStr'])) ? $this->_run_mod_handler('nl2br', true, $_tmp) : smarty_modifier_nl2br($_tmp)); 
 echo '</td></tr><tr><td>&nbsp;</td></tr></table>'; 
 endif; 
 echo ''; 
 if ($this->_tpl_vars['infoStr']): 
 echo '<table width="100%" border="0" cellpadding="0" cellspacing="0"><tr><td bgcolor="#CCFFCC">'; 
 echo $this->_tpl_vars['infoStr']; 
 echo '</td></tr><tr><td>&nbsp;</td></tr></table>'; 
 endif; 
 echo '<table border="0" cellpadding="5" cellspacing="0" class="settings-table"><tr><td colspan="2" class="form-required-field">'; 
 echo $this->_tpl_vars['waStrings']['forms_req_fields']; 
 echo '</td></tr><tr><td class="nobr"'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'SERVER_NAME','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr1_opt1']; 
 echo ':&nbsp;</td><td>'; 
 if ($this->_tpl_vars['action'] == 'new'): 
 echo '<input name="serverData[SERVER_NAME]" type="text" class="control" value="'; 
 echo $this->_tpl_vars['serverData']['SERVER_NAME']; 
 echo '" style="width: 100%">'; 
 else: 
 echo '<strong style="font-size: 120%;">'; 
 echo $this->_tpl_vars['serverData']['SERVER_NAME']; 
 echo '</strong>'; 
 endif; 
 echo '</td></tr>'; 
 if ($this->_tpl_vars['action'] == 'new'): 
 echo '<tr><td class="comment">&nbsp;</td><td class="comment"><p class="comment">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr1_desc1']; 
 echo '</p><p class="comment"><b>'; 
 echo $this->_tpl_vars['waStrings']['lbl_form_note']; 
 echo '</b>: '; 
 echo $this->_tpl_vars['waStrings']['addserv_gr1_note1']; 
 echo '</p></td></tr><tr><td colspan="2">&nbsp;</td></tr>'; 
 endif; 
 echo '<tr><td colspan="2"><div class="formSection">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_name']; 
 echo '</div></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'HOST','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_opt1']; 
 echo ':*</td><td><input name="serverData[HOST]" type="text" class="control" value="'; 
 echo $this->_tpl_vars['serverData']['HOST']; 
 echo '" style="width: 100%"></td></tr><tr><td>&nbsp;</td><td class="comment">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_desc1']; 
 echo '</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_opt2']; 
 echo ':</td><td><input name="serverData[WEBASYST_HOST]" type="text" class="control" value="'; 
 echo $this->_tpl_vars['serverData']['WEBASYST_HOST']; 
 echo '" style="width: 100%"></td></tr><tr><td class="comment">&nbsp;</td><td class="comment">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_desc2']; 
 echo '</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'PORT','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_opt3']; 
 echo ':</td><td><input name="serverData[PORT]" type="text" class="control" value="'; 
 echo $this->_tpl_vars['serverData']['PORT']; 
 echo '"	style="width: 100%"></td></tr><tr><td>&nbsp;</td><td class="comment">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr2_desc3']; 
 echo '</td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><!-- ========================= --><tr><td height="21" colspan="2"><div class="formSection">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr4_name']; 
 echo '</div></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td valign="top"></td><td><table border="0" cellspacing="0" cellpadding="1">'; 
 $_from = $this->_tpl_vars['sys_languages']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['lang_data']):

 echo ''; 
 $this->assign('lang_id', $this->_tpl_vars['lang_data']['ID']); 
 echo ''; 
 if ($this->_tpl_vars['serverData']['LANGUAGES'][$this->_tpl_vars['lang_id']]): 
 echo ''; 
 $this->assign('languageSet', 1); 
 echo ''; 
 else: 
 echo ''; 
 $this->assign('languageSet', 0); 
 echo ''; 
 endif; 
 echo '<tr><td bgcolor="#FFFFFF">'; 
 if ($this->_tpl_vars['lang_id'] != 'eng'): 
 echo '<input type=checkbox name="serverData[LANGUAGES]['; 
 echo $this->_tpl_vars['lang_id']; 
 echo ']" value=1 '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['languageSet'],'true_val' => 1), $this);
 echo '>'; 
 else: 
 echo '<input type="checkbox" checked disabled>'; 
 endif; 
 echo '</td><td bgcolor="#FFFFFF">'; 
 echo $this->_tpl_vars['lang_data']['NAME']; 
 echo '</td></tr>'; 
 endforeach; endif; unset($_from); 
 echo '</table></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>&nbsp;</td><td class="comment"><p class="comment">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr4_desc']; 
 echo '</p><p class="comment"><b>'; 
 echo $this->_tpl_vars['waStrings']['lbl_form_note']; 
 echo '</b>: '; 
 echo $this->_tpl_vars['waStrings']['addserv_gr4_note1']; 
 echo '</p></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td colspan="2"><div class="formSection">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_name']; 
 echo '</div></td></tr><tr><td colspan=2>&nbsp;</td></tr><tr><td align=right valign=top><input type=radio value="TRUE" name="serverData[ADMIN_ADMINRIGHTS]" '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['serverData']['ADMIN_ADMINRIGHTS'],'true_val' => 'TRUE'), $this);
 echo '></td><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ADMIN_ADMINRIGHTS','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_opt1']; 
 echo '</td></tr><tr><td></td><td class=comment><p class=comment>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_desc1']; 
 echo '</p><p class=comment><b>'; 
 echo $this->_tpl_vars['waStrings']['lbl_form_note']; 
 echo '</b>: '; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_note1']; 
 echo '</p></td></tr><tr><td colspan=2>&nbsp;</td></tr><tr><td>&nbsp;</td><td><table cellpadding=0 cellspacing=2 border=0><tr><td class="nobr"'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ADMIN_USERNAME','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_opt2']; 
 echo ':&nbsp;</td><td><input name="serverData[ADMIN_USERNAME]" type="text" class="control" value="'; 
 echo $this->_tpl_vars['serverData']['ADMIN_USERNAME']; 
 echo '" style="width: 200px"></td></tr><tr><td class="nobr"'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ADMIN_PASSWORD','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_opt3']; 
 echo ':&nbsp;</td><td><input name="serverData[ADMIN_PASSWORD]" type="text" class="control" style="width: 200px" value="'; 
 echo $this->_tpl_vars['serverData']['ADMIN_PASSWORD']; 
 echo '"></td></tr></table></td></tr><tr><td colspan=2>&nbsp;</td></tr><tr><td align=right valign=top><input type=radio value="FALSE" name="serverData[ADMIN_ADMINRIGHTS]" '; 
 echo smarty_function_switchedOutput(array('str1' => 'checked','str2' => "",'val' => $this->_tpl_vars['serverData']['ADMIN_ADMINRIGHTS'],'true_val' => 'FALSE'), $this);
 echo '></td><td'; 
 echo smarty_function_conditionalOutput(array('invalidField' => $this->_tpl_vars['invalidField'],'field' => 'ADMIN_ADMINRIGHTS','text' => $this->_tpl_vars['invalidFieldMarkup']), $this);
 echo '>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_opt4']; 
 echo '</td></tr><tr><td></td><td class=comment>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr5_desc2']; 
 echo '</td></tr><!-- ========================= --><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td colspan="2"><div class="formSection">'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr3_name']; 
 echo '</div></td></tr><tr><td>&nbsp;</td><td>&nbsp;</td></tr><tr><td>'; 
 echo $this->_tpl_vars['waStrings']['addserv_gr3_opt1']; 
 echo ':</td><td><input name="serverData[DBCHARSET]" type="text" class="control" value="'; 
 echo $this->_tpl_vars['serverData']['DBCHARSET']; 
 echo '"	style="width: 100%"></td></tr><!-- ========================= --><tr><td>'; 
 if ($this->_tpl_vars['action'] == 'edit'): 
 echo '<input type="hidden" value="'; 
 echo $this->_tpl_vars['serverData']['SERVER_NAME']; 
 echo '" name="serverData[SERVER_NAME]">'; 
 endif; 
 echo '<input type="hidden" value="'; 
 echo $this->_tpl_vars['action']; 
 echo '" name="action"> <input type="hidden" value="1" name="edited"><input name="languageToDelete" type="hidden"> </td><td>&nbsp;</td></tr><tr><td colspan="2"><table width="100%" border="0" cellspacing="0" cellpadding="0"><tr><td><input type="submit" name="savebtn" value="'; 
 echo $this->_tpl_vars['buttonCaption']; 
 echo '">'; 
 if ($this->_tpl_vars['action'] == 'edit'): 
 echo '<td align=right>&nbsp; <input name="deletebtn" type="submit" value="'; 
 echo $this->_tpl_vars['waStrings']['btn_delete']; 
 echo '" onClick="return confirm(\''; 
 echo $this->_tpl_vars['waStrings']['addserv_query_delete']; 
 echo '\');">'; 
 endif; 
 echo '</td></tr></table></td></tr></table>'; 
 endif; 
 echo '</form>'; ?>

<script type="text/javascript">
<!--
document.body.onload = function(){focusControl(<?php if ($this->_tpl_vars['invalidField']): ?>'serverData[<?php echo $this->_tpl_vars['invalidField']; ?>
]'<?php elseif ($this->_tpl_vars['action'] == 'new'): ?>'serverData[SERVER_NAME]'<?php else: ?>'serverData[HOST]'<?php endif; ?>);};
//-->
</script>
<!-- /addmodserver.html -->