<?php /* Smarty version 2.6.26, created on 2012-06-07 20:12:29
         compiled from backend/addmod_language.tpl.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'set_query_html', 'backend/addmod_language.tpl.html', 2, false),array('modifier', 'translate', 'backend/addmod_language.tpl.html', 4, false),array('modifier', 'escape', 'backend/addmod_language.tpl.html', 4, false),)), $this); ?>
	<h1 class="breadcrumbs">
		<a href="<?php echo ((is_array($_tmp='?ukey=languages')) ? $this->_run_mod_handler('set_query_html', true, $_tmp) : smarty_modifier_set_query_html($_tmp)); ?>
"><?php echo 'Languages & Translation'; ?>
</a>
		&raquo;
		<?php echo ((is_array($_tmp=$this->_tpl_vars['CurrentDivision']['name'])) ? $this->_run_mod_handler('translate', true, $_tmp) : smarty_modifier_translate($_tmp)); 
 if ($this->_tpl_vars['language']['name']): ?>: <?php echo ((is_array($_tmp=$this->_tpl_vars['language']['name'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); 
 endif; ?>
	</h1>

	<?php echo $this->_tpl_vars['MessageBlock']; ?>

	
	<form action="<?php echo ((is_array($_tmp='')) ? $this->_run_mod_handler('set_query_html', true, $_tmp) : smarty_modifier_set_query_html($_tmp)); ?>
" method="post" enctype="multipart/form-data">
		<input type="hidden" name="lang_id" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['language']['id'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
" />
		
		<ul class="form">
		
		<li id="lang_name">
			<?php echo 'Language name'; ?>
<br />
			<input class="text" type="text" size="25" name="lang_name" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['language']['name'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
" />
		</li>
		
		<li id="lang_ltr">
			<?php echo 'Text direction'; ?>
<br />
			<label><input class="text" type="radio" name="direction" value="0" <?php if (! $this->_tpl_vars['language']['direction']): ?>checked="checked"<?php endif; ?>/><?php echo 'LTR'; ?>
</label>
			<label><input class="text" type="radio" name="direction" value="1" <?php if ($this->_tpl_vars['language']['direction']): ?>checked="checked"<?php endif; ?>/><?php echo 'RTL'; ?>
</label>
			<div class="field_descr"><?php echo 'Choose between Left-to-right (LTR) and right-to-left (RTL) text direction.'; ?>
</div>
		</li>
		<li id="lang_iso2">
			<?php echo 'Language ISO2 code'; ?>
<br />
		
			<input class="text" type="text" maxlength="2" size="2" name="lang_iso2" value="<?php echo ((is_array($_tmp=$this->_tpl_vars['language']['iso2'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
" />
			<div class="field_descr"><?php echo '2 chars'; ?>
</div>
		</li>
		
		<li id="lang_enabled">
			<label for="lang_enabled"><?php echo 'Customers can switch to this language in storefront'; ?>
</label><br />
			<input type="checkbox" value="1" name="lang_enabled" id="lang_enabled" <?php if ($this->_tpl_vars['language']['enabled']): ?> checked="checked"<?php endif; 
 if ($this->_tpl_vars['language']['is_default']): ?> disabled<?php endif; ?> />
		</li>
		
		<li id="upload_thumbnail">
			<?php echo 'Language flag icon (<a href="http://www.famfamfam.com/lab/icons/flags/" target="_blank">download nice flag icons</a>)'; ?>
<br />
			<?php if ($this->_tpl_vars['language']['thumbnail_url']): ?>
			<img src="<?php echo ((is_array($_tmp=$this->_tpl_vars['language']['thumbnail_url'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
" alt="<?php echo ((is_array($_tmp=$this->_tpl_vars['language']['name'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'html') : smarty_modifier_escape($_tmp, 'html')); ?>
" hspace="6" align="left" />
			<?php endif; ?>
			<input class="file" type="file" name="upload_thumbnail" />
		</li>
		
		</ul>
		
		<br />
		<input type="submit" value="<?php echo 'Save'; ?>
" name="addmodlang" class="button" />
	</form>