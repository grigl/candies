<?php /* Smarty version 2.6.26, created on 2012-06-07 20:01:18
         compiled from home.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'component', 'home.html', 1, false),)), $this); ?>
<!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'njr3gga6','overridestyle' => ':9cg94r'), $this);
 echo smarty_function_component(array('cpt_id' => 'product_lists','list_id' => 'specialoffers','block_height' => '','overridestyle' => ''), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'de9hsbax','overridestyle' => ':xlwben'), $this);
 echo smarty_function_component(array('cpt_id' => 'root_categories','categories_col_num' => '3','show_sub_category' => 'enable_sub_category','subcategories_numberlimit' => '','subcategories_delimiter' => ' , ','overridestyle' => ':9a0dbx'), $this);?>
<!-- cpt_container_end -->