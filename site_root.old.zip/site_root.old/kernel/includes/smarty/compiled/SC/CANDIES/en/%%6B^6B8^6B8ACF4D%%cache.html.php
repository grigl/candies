<?php /* Smarty version 2.6.26, created on 2012-06-07 19:12:52
         compiled from cache.html */ ?>
<?php echo $this->_tpl_vars['cache_content']; ?>