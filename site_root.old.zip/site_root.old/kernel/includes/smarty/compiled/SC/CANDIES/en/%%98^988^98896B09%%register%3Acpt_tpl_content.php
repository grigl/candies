<?php /* Smarty version 2.6.26, created on 2012-06-07 20:01:18
         compiled from register:cpt_tpl_content */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'component', 'register:cpt_tpl_content', 4, false),)), $this); ?>
<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td id="container_top_left">
           <!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'logo','file' => 'mdr_companyname.gif','overridestyle' => ':yp917w'), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'gyfor9rz','overridestyle' => ':fkn8v9'), $this);?>
<!-- cpt_container_end -->
    </td>
    <td id="container_top"> 
          <!-- cpt_container_start --><!-- cpt_container_end -->
             
            <!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'divisions_navigation','divisions' => '29:54:183:107:32:189','view' => 'vertical','overridestyle' => ':3hlng3'), $this);
 echo smarty_function_component(array('cpt_id' => 'language_selection','view' => 'flags','overridestyle' => ':o9yiq1'), $this);?>
<!-- cpt_container_end -->
          
    </td>
    <td id="container_top_right"> 
           <!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'currency_selection','overridestyle' => ''), $this);
 echo smarty_function_component(array('cpt_id' => 'auxpages_navigation','select_pages' => 'all','auxpages' => '','view' => 'vertical','overridestyle' => ':8vk6df'), $this);?>
<!-- cpt_container_end -->
    </td>
  </tr>
  <tr> 
    <td id="container_left_sidebar"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'lch82oy0','overridestyle' => ':44lkp8'), $this);
 echo smarty_function_component(array('cpt_id' => 'category_tree','overridestyle' => ':wpe3jv'), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => '3vm6694u','overridestyle' => ':xvug4l'), $this);
 echo smarty_function_component(array('cpt_id' => 'product_search','overridestyle' => ':vxohqa'), $this);
 echo smarty_function_component(array('cpt_id' => 'tag_cloud','tags_num' => '10','overridestyle' => ':xkkezl'), $this);?>
<!-- cpt_container_end --></td>
    <td id="container_main_content"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'maincontent','overridestyle' => ':iwgkmz'), $this);?>
<!-- cpt_container_end --></td>
    <td id="container_right_sidebar"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'shopping_cart_info','overridestyle' => ''), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'rjxn8oml','overridestyle' => ':bgt879'), $this);
 echo smarty_function_component(array('cpt_id' => 'news_short_list','news_num' => '5','overridestyle' => ''), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'n0oy9wvn','overridestyle' => ':eulew6'), $this);
 echo smarty_function_component(array('cpt_id' => 'survey','overridestyle' => ''), $this);?>
<!-- cpt_container_end --></td>
  </tr>
</table>

<br />
<div id="container_footer">
<center>
<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'divisions_navigation','divisions' => '54:183:107:32:33:189','view' => 'horizontal','overridestyle' => ':b3r4fu'), $this);?>
<!-- cpt_container_end --></td>
</tr>
</table>
</center>
</div><br />
<div class="small" style="text-align:center"><i>&copy; <a href="<?php echo @CONF_FULL_SHOP_URL; ?>
"><u><?php echo @CONF_SHOP_NAME; ?>
</u></a>.
</i><br />
</div>
<script type="text/javascript">
roundElems();
</script>