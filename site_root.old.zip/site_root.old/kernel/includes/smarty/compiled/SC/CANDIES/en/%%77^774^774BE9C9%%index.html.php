<?php /* Smarty version 2.6.26, created on 2012-06-07 17:44:25
         compiled from index.html */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'component', 'index.html', 4, false),)), $this); ?>
<div class="all_wrapper">
<table width="100%" border="0" cellpadding="0" cellspacing="0" class="tls_topbar">
<tr>
<td id="container_topbar_left"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'custom_html','code' => '8g1gd6h8','overridestyle' => ':7n698c'), $this);?>
<!-- cpt_container_end --></td>
<td id="container_topbar"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'divisions_navigation','divisions' => '29:54:183:107:32:189','view' => 'horizontal','overridestyle' => ':8g3ted'), $this);?>
<!-- cpt_container_end --></td>
<td id="container_topbar_right"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'jymcwcmu','overridestyle' => ':5zs8lv'), $this);?>
<!-- cpt_container_end --></td>
</tr>
</table>

<table width="100%" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td id="container_top_left"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'auxpages_navigation','select_pages' => 'all','auxpages' => '','view' => 'vertical','overridestyle' => ':3xaz8c'), $this);?>
<!-- cpt_container_end --></td>
    <td id="container_top"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'p5kgoddr','overridestyle' => ':75man4'), $this);
 echo smarty_function_component(array('cpt_id' => 'language_selection','view' => 'flags','overridestyle' => ':r0065a'), $this);?>
<!-- cpt_container_end --></td>
    <td id="container_top_right"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'shopping_cart_info','overridestyle' => ''), $this);
 echo smarty_function_component(array('cpt_id' => 'currency_selection','overridestyle' => ':wta1vr'), $this);?>
<!-- cpt_container_end --></td>
  </tr>
</table>

 <table width="100%" border="0" cellpadding="0" cellspacing="0">  
  <tr>
    <td id="container_left_sidebar"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'custom_html','code' => 'c7wj287f','overridestyle' => ':9unr4j'), $this);
 echo smarty_function_component(array('cpt_id' => 'category_tree','overridestyle' => ':wpe3jv'), $this);
 echo smarty_function_component(array('cpt_id' => 'product_search','overridestyle' => ':vxohqa'), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => '0b6u45d4','overridestyle' => ':5hckss'), $this);
 echo smarty_function_component(array('cpt_id' => 'news_short_list','news_num' => '5','overridestyle' => ':06h816'), $this);
 echo smarty_function_component(array('cpt_id' => 'custom_html','code' => '7tqa7d2d','overridestyle' => ':xyeq10'), $this);
 echo smarty_function_component(array('cpt_id' => 'survey','overridestyle' => ''), $this);?>
<!-- cpt_container_end --></td>
    <td id="container_main_content"><!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'maincontent','overridestyle' => ':iwgkmz'), $this);?>
<!-- cpt_container_end --></td>
  </tr>
</table>


<div id="container_footer">
<center>
<table border="0" cellpadding="0" cellspacing="0">
<tr>
<td>
<!-- cpt_container_start --><?php echo smarty_function_component(array('cpt_id' => 'divisions_navigation','divisions' => '107:32:33:35','view' => 'horizontal','overridestyle' => ':b3r4fu'), $this);?>
<!-- cpt_container_end --></td>
</tr>
</table>
</center>
</div>

<div class="small" style="text-align:center"><i>&copy; <a href="<?php echo @CONF_FULL_SHOP_URL; ?>
"><u><?php echo @CONF_SHOP_NAME; ?>
</u></a>.</i></div>


</div>