<?
	include_once("wainit.php");
	Kernel::incPackage("json");
?>