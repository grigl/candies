<?php

interface iController 
{
    public function exec();
    
    public function display();
}

?>