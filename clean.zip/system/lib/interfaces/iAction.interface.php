<?php

interface iAction 
{
	
}

?>