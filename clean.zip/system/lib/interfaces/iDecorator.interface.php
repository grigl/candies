<?php

interface iDecorator 
{
    public function display(Action $action);
}