<?php

class DbCacher extends FileCacher 
{
    
}

?>