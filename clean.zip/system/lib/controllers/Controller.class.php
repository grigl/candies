<?php

class Controller implements iController 
{
    public function exec()
    {
        
    }

    public function display()
    {
    	
    }
}

?>