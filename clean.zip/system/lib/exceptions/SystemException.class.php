<?php

class SystemException extends Exception
{
	
}

?>