<?php 
	define("USE_LOCALIZATION", true);
//	define("CACHE_ENABLE", true);
	define("REVISION", 23);
//	define("DEVELOPER", true);
?>
