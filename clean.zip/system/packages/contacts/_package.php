<?php
	Kernel::incPackage("folders_tree");
	
	include_once("CMFolder.php");
	include_once("CMFoldersTree.php");
?>