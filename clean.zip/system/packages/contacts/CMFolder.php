<?php
	class CMFolder extends WbsFolderNode {
		
	}
?>