<?php

	define( "PAGE_BLANK", "AA/html/scripts/blank.php" );
	define( "PAGE_TIPSANDTRICKS", "AA/html/scripts/tipsandtricks.php" );
	define( "PAGE_LAST", "LAST_PAGE" );
	define( "START_PAGE", "START_PAGE" );
	define( "USE_BLANK", "BLANK" );
	define( "USE_LAST", "LAST" );
	define( "USE_TIPSANDTRICKS", "TIPSANDTRICKS" );
	
	define("DEF_LANGUAGE", "eng");
	define("LAST_VISIT_OFFSET", 3*60);
	define("LAST_VISIT_BIGOFFSET", 60*60);
	
?>