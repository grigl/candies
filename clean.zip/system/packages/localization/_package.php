<?php
	include_once(WBS_DIR . "kernel/includes/locloader.class.php");
	include_once("Locale.php");
?>