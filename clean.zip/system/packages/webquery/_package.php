<?
	include_once("WebQuery.php");

	// static initialize
	WebQuery::initialize();
?>