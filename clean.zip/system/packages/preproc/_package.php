<?php
	define("WBS_SMARTY_DIR", WBS_ROOT_PATH . "/kernel/includes/smarty/");
	
	include_once(WBS_SMARTY_DIR . "Smarty.class.php");
	include_once("Preproc.php");
?>