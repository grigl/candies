<?php
	/**************************************************************************************
	* require files
	**************************************************************************************/
	require_once ("Wbs.php");
	require_once ("WbsSystem.php");
	require_once ("WbsSystemFiles.php");
	require_once ("Dbkey.php");
	require_once ("DbkeyFiles.php");
	require_once ("Screen.php");
	require_once ("WbsApplication.php");
?>