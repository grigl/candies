<?php
	/**************************************************************************************
	* require files
	**************************************************************************************/
	require_once ("CSqlQuery.php");
	require_once ("CSqlFilter.php");
	require_once ("CSelectSqlQuery.php");
	require_once ("CChangeSqlQuery.php");
	require_once ("CInsertSqlQuery.php");
	require_once ("CUpdateSqlQuery.php");
	require_once ("CDeleteSqlQuery.php");
	require_once ("CReplaceSqlQuery.php"); 
?>