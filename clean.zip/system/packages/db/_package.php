<?php
	Kernel::incPackage("sql_query");
	
	require_once("MysqlDb.php");
	require_once("Wdb.php");
?>