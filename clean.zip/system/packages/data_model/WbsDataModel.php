<?php
	// Abstract records and folders factory for application
	abstract class WbsDataModel {
		function createRecord() {
		}
		
		function createFolder() {
		}
	}
?>