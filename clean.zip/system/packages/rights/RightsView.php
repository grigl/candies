<?php

class RightsView 
{
	
}



?>