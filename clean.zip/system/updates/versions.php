<?php
/**
 * Describe versions
 * 
 */

	$_VERSIONS = array(
		'278' => array(
			'SUBVERSIONS' => array(),
			'PARAMS' => array()
		),
		'280' => array(
			'SUBVERSIONS' => array(),
			'PARAMS' => array()
		),
		'286' => array(
			'SUBVERSIONS' => array(),
			'PARAMS' => array()
		),
		'287' => array(
			'SUBVERSIONS' => array(),
			'PARAMS' => array()
		),		
	);
?>