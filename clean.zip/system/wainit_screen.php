<?php
	include_once("wainit.php");
	Kernel::incPackage("preproc");
?>