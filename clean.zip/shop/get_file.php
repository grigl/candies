<?php
chdir('../published/SC/html/scripts');
include( "get_file.php");
 ?>