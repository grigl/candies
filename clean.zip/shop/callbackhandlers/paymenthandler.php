<?php
chdir('../../published/SC/html/scripts/callbackhandlers/');
require_once(basename(__FILE__));
?>