<?php
$_GET['frontend']=1;
chdir('../published/SC/html/scripts/');include "index.php"
?>