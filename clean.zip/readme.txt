Dear Customer,


To install WebAsyst applications on your web server:


1. Make sure you have safe_mode=OFF in php.ini file on your server.

2. Enable JavaScript in your browser.

3. Open install.php file, press Install button and follow further instructions.


Thank you for using WebAsyst Collaboration Software.


Should you have any questions feel free to contact support@webasyst.net

--
WebAsyst, LLC
PO Box 25331
Wilmington
DE 19899
U.S.A.

www.webasyst.net
