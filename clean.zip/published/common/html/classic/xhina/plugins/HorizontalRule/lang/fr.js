// I18N constants
// LANG: "fr", ENCODING: UTF-8
{
  "Insert/edit horizontal rule": "Insérer une règle horizontale",
  "Horizontal Rule": "Règle horizontale",
  "Layout": "Layout",
  "Width:": "Largeur",
  "percent": "pourcent",
  "pixels": "pixels",
  "Height:": "Hauteur",
  "Alignment:": "Alignement",
  "Left": "Gauche",
  "Center": "Centre",
  "Right": "Droite",
  "Style": "Style",
  "Color:": "Couleur",
  "No shading": "Pas d'ombre",
  "Note:": "Note",
  "To select an existing horizontal rule, a double-click may be needed.": "Pour sélectionner une règle horizontale, un double-clic peut être nécessaire."
};