// I18N constants
// LANG: "de", ENCODING: UTF-8
{ 
	"Insert Smiley": "Smiley einfügen",
	"Smiley": "Smiley",
	"Cancel": "Abbrechen"
};