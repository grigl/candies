// I18N for the Equation plugin
// LANG: "nb", ENCODING: UTF-8
// translated: Kim Steinhaug, http://www.steinhaug.com/, kim@steinhaug.com
{
  "Equation Editor": "Formeleditor",
  "Select operation": "Velg formel",
  "Insert": "Sett inn",
  "Cancel": "Avbryt"
};