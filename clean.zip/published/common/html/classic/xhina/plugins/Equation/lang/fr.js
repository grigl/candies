// I18N for the Equation plugin
// LANG: "fr", ENCODING: UTF-8
{
  "Equation Editor": "Editeur d'équation"
};