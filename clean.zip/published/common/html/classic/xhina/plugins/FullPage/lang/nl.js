// I18N for the FullPage plugin
// LANG: "nl", ENCODING: UTF-8
{
  "Alternate style-sheet:": "Wisselen van style-sheet:",
  "Background color:": "Achtergrondkleur:",
  "Cancel": "Annuleren",
  "DOCTYPE:": "DOCTYPE:",
  "Document properties": "Documenteigenschappen",
  "Document title:": "Documenttitel:",
  "OK": "OK",
  "Primary style-sheet:": "Primaire style-sheet:",
  "Text color:": "Tekstkleur:"
};