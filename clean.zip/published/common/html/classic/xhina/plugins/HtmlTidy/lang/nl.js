// I18N constants
// LANG: "nl", ENCODING: UTF-8
{
  "HT-html-tidy": "HTML opschonen"
};