tinyMCE.addI18n('en.toolbartoggle',{
	desc : 'Show/hide extra toolbars'
});